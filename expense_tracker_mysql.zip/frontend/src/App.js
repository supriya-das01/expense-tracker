import React from 'react';
import ExpensePage from './components/ExpensePage';

function App() {
  return <ExpensePage />;
}

export default App;
